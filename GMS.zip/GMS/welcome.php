
<!doctype html>
<html>
<head>
<meta charset="utf-8">
<title>Welcome</title>
<link rel="stylesheet"  href="welcome_style.css" />
</head>

<body>

<div class="wrapper">
	
	<!--This is header-->
	<div class="header" align="center"><h1>TADIWA</h1><h2>(TADIWA SYSTEM)</h2></div>
	<!--End of header-->
	
	
	<!--This is content-->
	<div class="content">
	<br>
		<h2 style="padding: 10px; text-decoration: underline; font-weight: bold;">PLEASE CHOOSE YOUR FIELD BELOW TO CONTINUE:</h2>
	<br>
		
		 <button class="button2" style="vertical-align: middle" onclick="window.location.href='http://localhost:8080/GMS/principal/login.php'" ><h2>PRINCIPAL</h2></button>
		 
		 <button class="button2" style="vertical-align: middle" onclick="window.location.href='http://localhost:8080/GMS/supervisor/login.php'" ><h2>SUPERVISOR</h2></button>
		 
		 <button class="button2" style="vertical-align: middle" onclick="window.location.href='http://localhost:8080/GMS/receiption/login.php'" ><h2>RECEPTIONIST</h2></button>
		 
		 <button class="button2" style="vertical-align: middle" onclick="window.location.href='http://localhost:8080/GMS/bursar/login.php'" ><h2>BURSAR</h2></button>
		 
		 <button class="button2" style="vertical-align: middle" onclick="window.location.href='http://localhost:8080/GMS/admin/login.php'" ><h2>ADMIN</h2></button>
		    	
	</div>
	<!--End of content-->
	
	<!--This is Footer-->
	<div align="center" style="background-color:#16365d; font-size: 20px; color: #fff;" >
	<i>© 2017 ALL RIGHTS RESERVED – TADIWA</i>
	</div>
	<!--End of Footer-->
				
</div>



</body>


	
</html>






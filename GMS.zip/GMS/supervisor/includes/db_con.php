<?php

$con = mysqli_connect("localhost","root","","gms");
if (!$con) {
        die("Failed Databse Connection");
    }

?>


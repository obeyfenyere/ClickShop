<?php

$con = mysqli_connect("localhost","root","","gsm");
if (!$con) {
        die("Failed Databse Connection");
    }

?>

